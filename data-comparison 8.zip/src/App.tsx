"use client"

import type React from "react"

import { useState } from "react"
import { DataComparison } from "./components/data-comparison"

function App() {
  const [countryCode, setCountryCode] = useState<string>("")
  const [pageId, setPageId] = useState<string>("")
  const [isLoading, setIsLoading] = useState<boolean>(false)

  // Sample data from the three environments
  const stgData = [{ groupTag: "HERO_BAN" }, { groupTag: "live" }]
  const prePrdData = [{ groupTag: "HERO_BAN" }, { groupTag: "program" }]
  const prdData = [{ groupTag: "HERO_BAN" }, { groupTag: "live" }]

  // Function to handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call with timeout
    setTimeout(() => {
      // In a real app, you would fetch data based on countryCode and pageId
      setIsLoading(false)
    }, 500)
  }

  return (
    <main className="container mx-auto py-10 px-4">
      <h1 className="text-3xl font-bold mb-6">Environment Data Comparison</h1>

      <div className="mb-8 p-4 border rounded-lg bg-white">
        <form onSubmit={handleSubmit} className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <label htmlFor="countryCode" className="block text-sm font-medium mb-1">
              Country Code
            </label>
            <input
              id="countryCode"
              type="text"
              value={countryCode}
              onChange={(e) => setCountryCode(e.target.value)}
              className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="e.g. KR, US, JP"
            />
          </div>

          <div className="flex-1">
            <label htmlFor="pageId" className="block text-sm font-medium mb-1">
              Page ID
            </label>
            <input
              id="pageId"
              type="text"
              value={pageId}
              onChange={(e) => setPageId(e.target.value)}
              className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="e.g. home, detail"
            />
          </div>

          <div className="flex items-end">
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
              disabled={isLoading}
            >
              {isLoading ? "Loading..." : "Compare"}
            </button>
          </div>
        </form>

        {countryCode && pageId && (
          <div className="mt-4 text-sm">
            <p>
              Comparing data for <span className="font-semibold">{countryCode.toUpperCase()}</span> / Page ID:{" "}
              <span className="font-semibold">{pageId}</span>
            </p>
          </div>
        )}
      </div>

      <DataComparison stgData={stgData} prePrdData={prePrdData} prdData={prdData} />
    </main>
  )
}

export default App
