"use client"

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface DataItem {
  groupTag: string
}

interface DataComparisonProps {
  stgData: DataItem[]
  prePrdData: DataItem[]
  prdData: DataItem[]
}

export function DataComparison({ stgData, prePrdData, prdData }: DataComparisonProps) {
  // Get the maximum length of the three data arrays
  const maxLength = Math.max(stgData.length, prePrdData.length, prdData.length)

  // Create an array of indices up to the maximum length
  const indices = Array.from({ length: maxLength }, (_, i) => i)

  // Function to determine the color class based on comparison
  const getColorClass = (index: number) => {
    const stgValue = index < stgData.length ? stgData[index].groupTag : undefined
    const prePrdValue = index < prePrdData.length ? prePrdData[index].groupTag : undefined
    const prdValue = index < prdData.length ? prdData[index].groupTag : undefined

    // All values are the same
    if (stgValue === prePrdValue && prePrdValue === prdValue) {
      return "bg-green-100 dark:bg-green-900/30"
    }

    // All values are different
    if (stgValue !== prePrdValue && prePrdValue !== prdValue && stgValue !== prdValue) {
      return "bg-red-100 dark:bg-red-900/30"
    }

    // Some values are the same, some are different
    return "bg-yellow-100 dark:bg-yellow-900/30"
  }

  // Function to get specific cell color
  const getCellColor = (index: number, env: "stg" | "prePrd" | "prd") => {
    const stgValue = index < stgData.length ? stgData[index].groupTag : undefined
    const prePrdValue = index < prePrdData.length ? prePrdData[index].groupTag : undefined
    const prdValue = index < prdData.length ? prdData[index].groupTag : undefined

    // If all values are the same, use green
    if (stgValue === prePrdValue && prePrdValue === prdValue) {
      return "bg-green-100 dark:bg-green-900/30"
    }

    // For different values, determine which ones match
    if (env === "stg") {
      if (stgValue === prePrdValue && stgValue === prdValue) return "bg-green-100 dark:bg-green-900/30"
      if (stgValue === prePrdValue) return "bg-blue-100 dark:bg-blue-900/30" // Matches pre-prd only
      if (stgValue === prdValue) return "bg-purple-100 dark:bg-purple-900/30" // Matches prd only
      return "bg-red-100 dark:bg-red-900/30" // Matches nothing
    }

    if (env === "prePrd") {
      if (prePrdValue === stgValue && prePrdValue === prdValue) return "bg-green-100 dark:bg-green-900/30"
      if (prePrdValue === stgValue) return "bg-blue-100 dark:bg-blue-900/30" // Matches stg only
      if (prePrdValue === prdValue) return "bg-purple-100 dark:bg-purple-900/30" // Matches prd only
      return "bg-red-100 dark:bg-red-900/30" // Matches nothing
    }

    if (env === "prd") {
      if (prdValue === stgValue && prdValue === prePrdValue) return "bg-green-100 dark:bg-green-900/30"
      if (prdValue === stgValue) return "bg-purple-100 dark:bg-purple-900/30" // Matches stg only
      if (prdValue === prePrdValue) return "bg-purple-100 dark:bg-purple-900/30" // Matches pre-prd only
      return "bg-red-100 dark:bg-red-900/30" // Matches nothing
    }

    return ""
  }

  return (
    <Card className="p-4">
      <div className="mb-4">
        <h2 className="text-xl font-semibold mb-2">GroupTag Comparison</h2>
        <div className="flex flex-wrap gap-2 text-sm">
          <div className="flex items-center">
            <div className="w-4 h-4 mr-1 bg-green-100 dark:bg-green-900/30 border"></div>
            <span>All match</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 mr-1 bg-blue-100 dark:bg-blue-900/30 border"></div>
            <span>STG & PRE-PRD match</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 mr-1 bg-purple-100 dark:bg-purple-900/30 border"></div>
            <span>STG & PRD or PRE-PRD & PRD match</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 mr-1 bg-red-100 dark:bg-red-900/30 border"></div>
            <span>All different</span>
          </div>
        </div>
      </div>

      <Tabs defaultValue="table">
        <TabsList>
          <TabsTrigger value="table">Table View</TabsTrigger>
          <TabsTrigger value="side-by-side">Side by Side</TabsTrigger>
        </TabsList>
        <TabsContent value="table" className="mt-4">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Index</TableHead>
                <TableHead>STG</TableHead>
                <TableHead>PRE-PRD</TableHead>
                <TableHead>PRD</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {indices.map((index) => (
                <TableRow key={index}>
                  <TableCell>{index}</TableCell>
                  <TableCell className={getCellColor(index, "stg")}>
                    {index < stgData.length ? stgData[index].groupTag : "—"}
                  </TableCell>
                  <TableCell className={getCellColor(index, "prePrd")}>
                    {index < prePrdData.length ? prePrdData[index].groupTag : "—"}
                  </TableCell>
                  <TableCell className={getCellColor(index, "prd")}>
                    {index < prdData.length ? prdData[index].groupTag : "—"}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TabsContent>
        <TabsContent value="side-by-side" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="p-4">
              <h3 className="text-lg font-medium mb-2">STG Environment</h3>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Index</TableHead>
                    <TableHead>groupTag</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {stgData.map((item, index) => (
                    <TableRow key={index}>
                      <TableCell>{index}</TableCell>
                      <TableCell className={getCellColor(index, "stg")}>{item.groupTag}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>

            <Card className="p-4">
              <h3 className="text-lg font-medium mb-2">PRE-PRD Environment</h3>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Index</TableHead>
                    <TableHead>groupTag</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {prePrdData.map((item, index) => (
                    <TableRow key={index}>
                      <TableCell>{index}</TableCell>
                      <TableCell className={getCellColor(index, "prePrd")}>{item.groupTag}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>

            <Card className="p-4">
              <h3 className="text-lg font-medium mb-2">PRD Environment</h3>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Index</TableHead>
                    <TableHead>groupTag</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {prdData.map((item, index) => (
                    <TableRow key={index}>
                      <TableCell>{index}</TableCell>
                      <TableCell className={getCellColor(index, "prd")}>{item.groupTag}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      <div className="mt-6">
        <h3 className="text-lg font-medium mb-2">Summary of Differences</h3>
        <div className="space-y-2">
          {indices.map((index) => {
            const stgValue = index < stgData.length ? stgData[index].groupTag : "—"
            const prePrdValue = index < prePrdData.length ? prePrdData[index].groupTag : "—"
            const prdValue = index < prdData.length ? prdData[index].groupTag : "—"

            // Skip if all values are the same
            if (stgValue === prePrdValue && prePrdValue === prdValue) return null

            return (
              <div key={index} className="p-2 border rounded-md">
                <p className="font-medium">Index {index}:</p>
                <div className="grid grid-cols-3 gap-2 mt-1">
                  <div className={`p-1 rounded ${getCellColor(index, "stg")}`}>
                    <span className="font-medium">STG:</span> {stgValue}
                  </div>
                  <div className={`p-1 rounded ${getCellColor(index, "prePrd")}`}>
                    <span className="font-medium">PRE-PRD:</span> {prePrdValue}
                  </div>
                  <div className={`p-1 rounded ${getCellColor(index, "prd")}`}>
                    <span className="font-medium">PRD:</span> {prdValue}
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </Card>
  )
}
