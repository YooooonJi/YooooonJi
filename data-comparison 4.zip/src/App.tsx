"use client"

import type React from "react"

import { useState } from "react"

interface DataItem {
  groupTag: string
}

function App() {
  const [countryCode, setCountryCode] = useState<string>("")
  const [pageId, setPageId] = useState<string>("")
  const [isLoading, setIsLoading] = useState<boolean>(false)

  // Sample data from the three environments
  const stgData = [{ groupTag: "HERO_BAN" }, { groupTag: "live" }]
  const prePrdData = [{ groupTag: "HERO_BAN" }, { groupTag: "program" }]
  const prdData = [{ groupTag: "HERO_BAN" }, { groupTag: "live" }]

  // Get the maximum length of the three data arrays
  const maxLength = Math.max(stgData.length, prePrdData.length, prdData.length)

  // Create an array of indices up to the maximum length
  const indices = Array.from({ length: maxLength }, (_, i) => i)

  // Function to handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call with timeout
    setTimeout(() => {
      setIsLoading(false)
    }, 500)
  }

  // Function to get specific cell color
  const getCellColor = (index: number, env: "stg" | "prePrd" | "prd") => {
    const stgValue = index < stgData.length ? stgData[index].groupTag : undefined
    const prePrdValue = index < prePrdData.length ? prePrdData[index].groupTag : undefined
    const prdValue = index < prdData.length ? prdData[index].groupTag : undefined

    // If all values are the same, use green
    if (stgValue === prePrdValue && prePrdValue === prdValue) {
      return "bg-green-100 dark:bg-green-900/30"
    }

    // For different values, determine which ones match
    if (env === "stg") {
      if (stgValue === prePrdValue && stgValue === prdValue) return "bg-green-100 dark:bg-green-900/30"
      if (stgValue === prePrdValue) return "bg-blue-100 dark:bg-blue-900/30" // Matches pre-prd only
      if (stgValue === prdValue) return "bg-purple-100 dark:bg-purple-900/30" // Matches prd only
      return "bg-red-100 dark:bg-red-900/30" // Matches nothing
    }

    if (env === "prePrd") {
      if (prePrdValue === stgValue && prePrdValue === prdValue) return "bg-green-100 dark:bg-green-900/30"
      if (prePrdValue === stgValue) return "bg-blue-100 dark:bg-blue-900/30" // Matches stg only
      if (prePrdValue === prdValue) return "bg-purple-100 dark:bg-purple-900/30" // Matches prd only
      return "bg-red-100 dark:bg-red-900/30" // Matches nothing
    }

    if (env === "prd") {
      if (prdValue === stgValue && prdValue === prePrdValue) return "bg-green-100 dark:bg-green-900/30"
      if (prdValue === stgValue) return "bg-purple-100 dark:bg-purple-900/30" // Matches stg only
      if (prdValue === prePrdValue) return "bg-purple-100 dark:bg-purple-900/30" // Matches pre-prd only
      return "bg-red-100 dark:bg-red-900/30" // Matches nothing
    }

    return ""
  }

  return (
    <main className="container mx-auto py-10 px-4">
      <h1 className="text-3xl font-bold mb-6">Environment Data Comparison</h1>

      <div className="mb-8 p-4 border rounded-lg bg-white">
        <form onSubmit={handleSubmit} className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <label htmlFor="countryCode" className="block text-sm font-medium mb-1">
              Country Code
            </label>
            <input
              id="countryCode"
              type="text"
              value={countryCode}
              onChange={(e) => setCountryCode(e.target.value)}
              className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="e.g. KR, US, JP"
            />
          </div>

          <div className="flex-1">
            <label htmlFor="pageId" className="block text-sm font-medium mb-1">
              Page ID
            </label>
            <input
              id="pageId"
              type="text"
              value={pageId}
              onChange={(e) => setPageId(e.target.value)}
              className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="e.g. home, detail"
            />
          </div>

          <div className="flex items-end">
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
              disabled={isLoading}
            >
              {isLoading ? "Loading..." : "Compare"}
            </button>
          </div>
        </form>

        {countryCode && pageId && (
          <div className="mt-4 text-sm">
            <p>
              Comparing data for <span className="font-semibold">{countryCode.toUpperCase()}</span> / Page ID:{" "}
              <span className="font-semibold">{pageId}</span>
            </p>
          </div>
        )}
      </div>

      <div className="border rounded-lg p-4 bg-white">
        <div className="mb-4">
          <h2 className="text-xl font-semibold mb-2">GroupTag Comparison</h2>
          <div className="flex flex-wrap gap-2 text-sm">
            <div className="flex items-center">
              <div className="w-4 h-4 mr-1 bg-green-100 border"></div>
              <span>All match</span>
            </div>
            <div className="flex items-center">
              <div className="w-4 h-4 mr-1 bg-blue-100 border"></div>
              <span>STG & PRE-PRD match</span>
            </div>
            <div className="flex items-center">
              <div className="w-4 h-4 mr-1 bg-purple-100 border"></div>
              <span>STG & PRD or PRE-PRD & PRD match</span>
            </div>
            <div className="flex items-center">
              <div className="w-4 h-4 mr-1 bg-red-100 border"></div>
              <span>All different</span>
            </div>
          </div>
        </div>

        <div className="mb-4">
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-50">
                  <th className="border p-2 text-left">Index</th>
                  <th className="border p-2 text-left">STG</th>
                  <th className="border p-2 text-left">PRE-PRD</th>
                  <th className="border p-2 text-left">PRD</th>
                </tr>
              </thead>
              <tbody>
                {indices.map((index) => (
                  <tr key={index}>
                    <td className="border p-2">{index}</td>
                    <td className={`border p-2 ${getCellColor(index, "stg")}`}>
                      {index < stgData.length ? stgData[index].groupTag : "—"}
                    </td>
                    <td className={`border p-2 ${getCellColor(index, "prePrd")}`}>
                      {index < prePrdData.length ? prePrdData[index].groupTag : "—"}
                    </td>
                    <td className={`border p-2 ${getCellColor(index, "prd")}`}>
                      {index < prdData.length ? prdData[index].groupTag : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="mt-6">
          <h3 className="text-lg font-medium mb-2">Summary of Differences</h3>
          <div className="space-y-2">
            {indices.map((index) => {
              const stgValue = index < stgData.length ? stgData[index].groupTag : "—"
              const prePrdValue = index < prePrdData.length ? prePrdData[index].groupTag : "—"
              const prdValue = index < prdData.length ? prdData[index].groupTag : "—"

              // Skip if all values are the same
              if (stgValue === prePrdValue && prePrdValue === prdValue) return null

              return (
                <div key={index} className="p-2 border rounded-md">
                  <p className="font-medium">Index {index}:</p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mt-1">
                    <div className={`p-1 rounded ${getCellColor(index, "stg")}`}>
                      <span className="font-medium">STG:</span> {stgValue}
                    </div>
                    <div className={`p-1 rounded ${getCellColor(index, "prePrd")}`}>
                      <span className="font-medium">PRE-PRD:</span> {prePrdValue}
                    </div>
                    <div className={`p-1 rounded ${getCellColor(index, "prd")}`}>
                      <span className="font-medium">PRD:</span> {prdValue}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </main>
  )
}

export default App
