import { DataComparison } from "@/components/data-comparison"

export default function Home() {
  // Sample data from the three environments, removing the order property
  const stgData = [{ groupTag: "HERO_BAN" }, { groupTag: "live" }]

  const prePrdData = [{ groupTag: "HERO_BAN" }, { groupTag: "program" }]

  const prdData = [{ groupTag: "HERO_BAN" }, { groupTag: "live" }]

  return (
    <main className="container mx-auto py-10 px-4">
      <h1 className="text-3xl font-bold mb-6">Environment Data Comparison</h1>
      <DataComparison stgData={stgData} prePrdData={prePrdData} prdData={prdData} />
    </main>
  )
}
