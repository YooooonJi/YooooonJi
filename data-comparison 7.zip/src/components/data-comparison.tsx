"use client"

import { useState } from "react"

interface DataItem {
  groupTag: string
}

interface DataComparisonProps {
  stgData: DataItem[]
  prePrdData: DataItem[]
  prdData: DataItem[]
}

type EnvironmentType = "stg" | "prePrd" | "prd"

export function DataComparison({ stgData, prePrdData, prdData }: DataComparisonProps) {
  const [activeTab, setActiveTab] = useState<"table" | "sideBySide">("table")
  const [env1, setEnv1] = useState<EnvironmentType>("stg")
  const [env2, setEnv2] = useState<EnvironmentType>("prePrd")

  // Get the maximum length of the three data arrays
  const maxLength = Math.max(stgData.length, prePrdData.length, prdData.length)

  // Create an array of indices up to the maximum length
  const indices = Array.from({ length: maxLength }, (_, i) => i)

  // Function to get data for a specific environment
  const getEnvData = (env: EnvironmentType) => {
    switch (env) {
      case "stg":
        return stgData
      case "prePrd":
        return prePrdData
      case "prd":
        return prdData
    }
  }

  // Function to get display name for environment
  const getEnvDisplayName = (env: EnvironmentType) => {
    switch (env) {
      case "stg":
        return "STG"
      case "prePrd":
        return "PRE-PRD"
      case "prd":
        return "PRD"
    }
  }

  // Function to find indices of a groupTag in other environments
  const findIndicesInOtherEnvs = (groupTag: string, currentEnv: EnvironmentType) => {
    const result: { env: EnvironmentType; index: number }[] = []

    // Check STG if current env is not STG
    if (currentEnv !== "stg") {
      const stgIndex = stgData.findIndex((item) => item.groupTag === groupTag)
      if (stgIndex !== -1) {
        result.push({ env: "stg", index: stgIndex })
      }
    }

    // Check PRE-PRD if current env is not PRE-PRD
    if (currentEnv !== "prePrd") {
      const prePrdIndex = prePrdData.findIndex((item) => item.groupTag === groupTag)
      if (prePrdIndex !== -1) {
        result.push({ env: "prePrd", index: prePrdIndex })
      }
    }

    // Check PRD if current env is not PRD
    if (currentEnv !== "prd") {
      const prdIndex = prdData.findIndex((item) => item.groupTag === groupTag)
      if (prdIndex !== -1) {
        result.push({ env: "prd", index: prdIndex })
      }
    }

    return result
  }

  // Function to get tooltip text for a groupTag
  const getTooltipText = (groupTag: string, currentEnv: EnvironmentType) => {
    const indices = findIndicesInOtherEnvs(groupTag, currentEnv)
    if (indices.length === 0) return "Only exists in this environment"

    return indices.map((item) => `${getEnvDisplayName(item.env)}: ${item.index}`).join(", ")
  }

  // Function to get specific cell color
  const getCellColor = (index: number, env: EnvironmentType) => {
    const stgValue = index < stgData.length ? stgData[index].groupTag : undefined
    const prePrdValue = index < prePrdData.length ? prePrdData[index].groupTag : undefined
    const prdValue = index < prdData.length ? prdData[index].groupTag : undefined

    // If all values are the same, use green
    if (stgValue === prePrdValue && prePrdValue === prdValue) {
      return "bg-green-100 dark:bg-green-900/30"
    }

    // For different values, determine which ones match
    if (env === "stg") {
      if (stgValue === prePrdValue && stgValue === prdValue) return "bg-green-100 dark:bg-green-900/30"
      if (stgValue === prePrdValue) return "bg-blue-100 dark:bg-blue-900/30" // Matches pre-prd only
      if (stgValue === prdValue) return "bg-purple-100 dark:bg-purple-900/30" // Matches prd only
      return "bg-red-100 dark:bg-red-900/30" // Matches nothing
    }

    if (env === "prePrd") {
      if (prePrdValue === stgValue && prePrdValue === prdValue) return "bg-green-100 dark:bg-green-900/30"
      if (prePrdValue === stgValue) return "bg-blue-100 dark:bg-blue-900/30" // Matches stg only
      if (prePrdValue === prdValue) return "bg-purple-100 dark:bg-purple-900/30" // Matches prd only
      return "bg-red-100 dark:bg-red-900/30" // Matches nothing
    }

    if (env === "prd") {
      if (prdValue === stgValue && prdValue === prePrdValue) return "bg-green-100 dark:bg-green-900/30"
      if (prdValue === stgValue) return "bg-purple-100 dark:bg-purple-900/30" // Matches stg only
      if (prdValue === prePrdValue) return "bg-purple-100 dark:bg-purple-900/30" // Matches pre-prd only
      return "bg-red-100 dark:bg-red-900/30" // Matches nothing
    }

    return ""
  }

  // Function to get color for side by side comparison
  const getSideBySideColor = (index: number, env: EnvironmentType) => {
    if (env === env1 || env === env2) {
      const env1Data = getEnvData(env1)
      const env2Data = getEnvData(env2)

      const env1Value = index < env1Data.length ? env1Data[index].groupTag : undefined
      const env2Value = index < env2Data.length ? env2Data[index].groupTag : undefined

      if (env1Value === env2Value) {
        return "bg-green-100 dark:bg-green-900/30" // Both match
      } else {
        return "bg-red-100 dark:bg-red-900/30" // Different
      }
    }
    return ""
  }

  // Function to get tooltip text for side by side comparison
  const getSideBySideTooltip = (groupTag: string, currentEnv: EnvironmentType) => {
    const otherEnv = currentEnv === env1 ? env2 : env1
    const otherEnvData = getEnvData(otherEnv)
    const otherEnvIndex = otherEnvData.findIndex((item) => item.groupTag === groupTag)

    if (otherEnvIndex !== -1) {
      return `${getEnvDisplayName(otherEnv)}: ${otherEnvIndex}`
    }
    return "Only exists in this environment"
  }

  return (
    <div className="border rounded-lg p-4 bg-white">
      <div className="mb-4">
        <h2 className="text-xl font-semibold mb-2">GroupTag Comparison</h2>
        <div className="flex flex-wrap gap-2 text-sm">
          <div className="flex items-center">
            <div className="w-4 h-4 mr-1 bg-green-100 border"></div>
            <span>All match</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 mr-1 bg-blue-100 border"></div>
            <span>STG & PRE-PRD match</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 mr-1 bg-purple-100 border"></div>
            <span>STG & PRD or PRE-PRD & PRD match</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 mr-1 bg-red-100 border"></div>
            <span>All different</span>
          </div>
        </div>
      </div>

      <div className="mb-4">
        <div className="flex border-b">
          <button
            className={`px-4 py-2 font-medium ${
              activeTab === "table" ? "border-b-2 border-blue-500 text-blue-600" : "text-gray-500"
            }`}
            onClick={() => setActiveTab("table")}
          >
            Table View
          </button>
          <button
            className={`px-4 py-2 font-medium ${
              activeTab === "sideBySide" ? "border-b-2 border-blue-500 text-blue-600" : "text-gray-500"
            }`}
            onClick={() => setActiveTab("sideBySide")}
          >
            Side by Side
          </button>
        </div>
      </div>

      {activeTab === "table" ? (
        <div className="mb-4">
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-50">
                  <th className="border p-2 text-left">Index</th>
                  <th className="border p-2 text-left">STG</th>
                  <th className="border p-2 text-left">PRE-PRD</th>
                  <th className="border p-2 text-left">PRD</th>
                </tr>
              </thead>
              <tbody>
                {indices.map((index) => (
                  <tr key={index}>
                    <td className="border p-2">{index}</td>
                    <td
                      className={`border p-2 ${getCellColor(index, "stg")} relative group cursor-help`}
                      title={
                        index < stgData.length
                          ? getTooltipText(stgData[index].groupTag, "stg")
                          : "No data at this index"
                      }
                    >
                      {index < stgData.length ? (
                        <>
                          {stgData[index].groupTag}
                          <div className="absolute hidden group-hover:block bg-black text-white text-xs rounded py-1 px-2 left-full ml-2 top-1/2 transform -translate-y-1/2 z-10 whitespace-nowrap">
                            {getTooltipText(stgData[index].groupTag, "stg")}
                          </div>
                        </>
                      ) : (
                        "—"
                      )}
                    </td>
                    <td
                      className={`border p-2 ${getCellColor(index, "prePrd")} relative group cursor-help`}
                      title={
                        index < prePrdData.length
                          ? getTooltipText(prePrdData[index].groupTag, "prePrd")
                          : "No data at this index"
                      }
                    >
                      {index < prePrdData.length ? (
                        <>
                          {prePrdData[index].groupTag}
                          <div className="absolute hidden group-hover:block bg-black text-white text-xs rounded py-1 px-2 left-full ml-2 top-1/2 transform -translate-y-1/2 z-10 whitespace-nowrap">
                            {getTooltipText(prePrdData[index].groupTag, "prePrd")}
                          </div>
                        </>
                      ) : (
                        "—"
                      )}
                    </td>
                    <td
                      className={`border p-2 ${getCellColor(index, "prd")} relative group cursor-help`}
                      title={
                        index < prdData.length
                          ? getTooltipText(prdData[index].groupTag, "prd")
                          : "No data at this index"
                      }
                    >
                      {index < prdData.length ? (
                        <>
                          {prdData[index].groupTag}
                          <div className="absolute hidden group-hover:block bg-black text-white text-xs rounded py-1 px-2 right-full mr-2 top-1/2 transform -translate-y-1/2 z-10 whitespace-nowrap">
                            {getTooltipText(prdData[index].groupTag, "prd")}
                          </div>
                        </>
                      ) : (
                        "—"
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="mb-4">
          <div className="flex flex-col md:flex-row gap-4 mb-4">
            <div className="flex-1">
              <label htmlFor="env1" className="block text-sm font-medium mb-1">
                Environment 1
              </label>
              <select
                id="env1"
                value={env1}
                onChange={(e) => setEnv1(e.target.value as EnvironmentType)}
                className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="stg">STG</option>
                <option value="prePrd">PRE-PRD</option>
                <option value="prd">PRD</option>
              </select>
            </div>
            <div className="flex-1">
              <label htmlFor="env2" className="block text-sm font-medium mb-1">
                Environment 2
              </label>
              <select
                id="env2"
                value={env2}
                onChange={(e) => setEnv2(e.target.value as EnvironmentType)}
                className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="stg">STG</option>
                <option value="prePrd">PRE-PRD</option>
                <option value="prd">PRD</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border rounded-lg p-4">
              <h3 className="text-lg font-medium mb-2">{getEnvDisplayName(env1)}</h3>
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="border p-2 text-left">Index</th>
                    <th className="border p-2 text-left">groupTag</th>
                  </tr>
                </thead>
                <tbody>
                  {getEnvData(env1).map((item, index) => (
                    <tr key={index}>
                      <td className="border p-2">{index}</td>
                      <td
                        className={`border p-2 ${getSideBySideColor(index, env1)} relative group cursor-help`}
                        title={getSideBySideTooltip(item.groupTag, env1)}
                      >
                        {item.groupTag}
                        <div className="absolute hidden group-hover:block bg-black text-white text-xs rounded py-1 px-2 left-full ml-2 top-1/2 transform -translate-y-1/2 z-10 whitespace-nowrap">
                          {getSideBySideTooltip(item.groupTag, env1)}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="border rounded-lg p-4">
              <h3 className="text-lg font-medium mb-2">{getEnvDisplayName(env2)}</h3>
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="border p-2 text-left">Index</th>
                    <th className="border p-2 text-left">groupTag</th>
                  </tr>
                </thead>
                <tbody>
                  {getEnvData(env2).map((item, index) => (
                    <tr key={index}>
                      <td className="border p-2">{index}</td>
                      <td
                        className={`border p-2 ${getSideBySideColor(index, env2)} relative group cursor-help`}
                        title={getSideBySideTooltip(item.groupTag, env2)}
                      >
                        {item.groupTag}
                        <div className="absolute hidden group-hover:block bg-black text-white text-xs rounded py-1 px-2 right-full mr-2 top-1/2 transform -translate-y-1/2 z-10 whitespace-nowrap">
                          {getSideBySideTooltip(item.groupTag, env2)}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      <div className="mt-6">
        <h3 className="text-lg font-medium mb-2">Summary of Differences</h3>
        <div className="space-y-2">
          {indices.map((index) => {
            const stgValue = index < stgData.length ? stgData[index].groupTag : "—"
            const prePrdValue = index < prePrdData.length ? prePrdData[index].groupTag : "—"
            const prdValue = index < prdData.length ? prdData[index].groupTag : "—"

            // Skip if all values are the same
            if (stgValue === prePrdValue && prePrdValue === prdValue) return null

            return (
              <div key={index} className="p-2 border rounded-md">
                <p className="font-medium">Index {index}:</p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mt-1">
                  <div className={`p-1 rounded ${getCellColor(index, "stg")}`}>
                    <span className="font-medium">STG:</span> {stgValue}
                  </div>
                  <div className={`p-1 rounded ${getCellColor(index, "prePrd")}`}>
                    <span className="font-medium">PRE-PRD:</span> {prePrdValue}
                  </div>
                  <div className={`p-1 rounded ${getCellColor(index, "prd")}`}>
                    <span className="font-medium">PRD:</span> {prdValue}
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
