"use client"

import type React from "react"

import { BrowserRouter as Router, Route, Routes } from "react-router-dom"
import { ThemeProvider } from "./components/theme-provider"
import { useState } from "react"
import { DataComparison } from "./components/data-comparison"
import { Button } from "./components/ui/button"
import { Input } from "./components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "./components/ui/card"
import { Label } from "./components/ui/label"

function App() {
  const [countryCode, setCountryCode] = useState<string>("")
  const [pageId, setPageId] = useState<string>("")
  const [isLoading, setIsLoading] = useState<boolean>(false)

  // Sample data from the three environments
  const stgData = [{ groupTag: "HERO_BAN" }, { groupTag: "live" }]
  const prePrdData = [{ groupTag: "HERO_BAN" }, { groupTag: "program" }]
  const prdData = [{ groupTag: "HERO_BAN" }, { groupTag: "live" }]

  // Function to handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call with timeout
    setTimeout(() => {
      // In a real app, you would fetch data based on countryCode and pageId
      setIsLoading(false)
    }, 500)
  }

  return (
    <ThemeProvider defaultTheme="light" storageKey="data-comparison-theme">
      <Router>
        <Routes>
          <Route
            path="/"
            element={
              <main className="container mx-auto py-10 px-4">
                <h1 className="text-3xl font-bold mb-6">Environment Data Comparison</h1>

                <Card className="mb-8">
                  <CardHeader>
                    <CardTitle>Search Parameters</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleSubmit} className="flex flex-col md:flex-row gap-4">
                      <div className="flex-1 space-y-2">
                        <Label htmlFor="countryCode">Country Code</Label>
                        <Input
                          id="countryCode"
                          value={countryCode}
                          onChange={(e) => setCountryCode(e.target.value)}
                          placeholder="e.g. KR, US, JP"
                        />
                      </div>

                      <div className="flex-1 space-y-2">
                        <Label htmlFor="pageId">Page ID</Label>
                        <Input
                          id="pageId"
                          value={pageId}
                          onChange={(e) => setPageId(e.target.value)}
                          placeholder="e.g. home, detail"
                        />
                      </div>

                      <div className="flex items-end">
                        <Button type="submit" disabled={isLoading}>
                          {isLoading ? "Loading..." : "Compare"}
                        </Button>
                      </div>
                    </form>

                    {countryCode && pageId && (
                      <div className="mt-4 text-sm">
                        <p>
                          Comparing data for <span className="font-semibold">{countryCode.toUpperCase()}</span> / Page
                          ID: <span className="font-semibold">{pageId}</span>
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <DataComparison stgData={stgData} prePrdData={prePrdData} prdData={prdData} />
              </main>
            }
          />
        </Routes>
      </Router>
    </ThemeProvider>
  )
}

export default App
