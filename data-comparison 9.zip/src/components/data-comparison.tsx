"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface DataItem {
  groupTag: string
}

interface DataComparisonProps {
  stgData: DataItem[]
  prePrdData: DataItem[]
  prdData: DataItem[]
}

type EnvironmentType = "stg" | "prePrd" | "prd"

export function DataComparison({ stgData, prePrdData, prdData }: DataComparisonProps) {
  const [activeTab, setActiveTab] = useState<string>("table")
  const [env1, setEnv1] = useState<EnvironmentType>("stg")
  const [env2, setEnv2] = useState<EnvironmentType>("prePrd")
  const [hoveredGroupTag, setHoveredGroupTag] = useState<string | null>(null)

  // Get the maximum length of the three data arrays
  const maxLength = Math.max(stgData.length, prePrdData.length, prdData.length)

  // Create an array of indices up to the maximum length
  const indices = Array.from({ length: maxLength }, (_, i) => i)

  // Function to get data for a specific environment
  const getEnvData = (env: EnvironmentType) => {
    switch (env) {
      case "stg":
        return stgData
      case "prePrd":
        return prePrdData
      case "prd":
        return prdData
    }
  }

  // Function to get display name for environment
  const getEnvDisplayName = (env: EnvironmentType) => {
    switch (env) {
      case "stg":
        return "STG"
      case "prePrd":
        return "PRE-PRD"
      case "prd":
        return "PRD"
    }
  }

  // Function to find indices of a groupTag in other environments
  const findIndicesInOtherEnvs = (groupTag: string, currentEnv: EnvironmentType) => {
    const result: { env: EnvironmentType; index: number }[] = []

    // Check STG if current env is not STG
    if (currentEnv !== "stg") {
      const stgIndex = stgData.findIndex((item) => item.groupTag === groupTag)
      if (stgIndex !== -1) {
        result.push({ env: "stg", index: stgIndex })
      }
    }

    // Check PRE-PRD if current env is not PRE-PRD
    if (currentEnv !== "prePrd") {
      const prePrdIndex = prePrdData.findIndex((item) => item.groupTag === groupTag)
      if (prePrdIndex !== -1) {
        result.push({ env: "prePrd", index: prePrdIndex })
      }
    }

    // Check PRD if current env is not PRD
    if (currentEnv !== "prd") {
      const prdIndex = prdData.findIndex((item) => item.groupTag === groupTag)
      if (prdIndex !== -1) {
        result.push({ env: "prd", index: prdIndex })
      }
    }

    return result
  }

  // Function to get tooltip text for a groupTag
  const getTooltipText = (groupTag: string, currentEnv: EnvironmentType) => {
    const indices = findIndicesInOtherEnvs(groupTag, currentEnv)
    if (indices.length === 0) return "Only exists in this environment"

    return indices.map((item) => `${getEnvDisplayName(item.env)}: ${item.index}`).join(", ")
  }

  // Function to check if a cell should be highlighted based on hovered groupTag
  const shouldHighlight = (index: number, env: EnvironmentType) => {
    if (!hoveredGroupTag) return false

    const data = getEnvData(env)
    return index < data.length && data[index].groupTag === hoveredGroupTag
  }

  // Function to get specific cell color
  const getCellColor = (index: number, env: EnvironmentType) => {
    const stgValue = index < stgData.length ? stgData[index].groupTag : undefined
    const prePrdValue = index < prePrdData.length ? prePrdData[index].groupTag : undefined
    const prdValue = index < prdData.length ? prdData[index].groupTag : undefined

    // If all values are the same, use green
    if (stgValue === prePrdValue && prePrdValue === prdValue) {
      return "bg-green-100 dark:bg-green-900/30"
    }

    // For different values, determine which ones match
    if (env === "stg") {
      if (stgValue === prePrdValue && stgValue === prdValue) return "bg-green-100 dark:bg-green-900/30"
      if (stgValue === prePrdValue) return "bg-blue-100 dark:bg-blue-900/30" // Matches pre-prd only
      if (stgValue === prdValue) return "bg-purple-100 dark:bg-purple-900/30" // Matches prd only
      return "bg-red-100 dark:bg-red-900/30" // Matches nothing
    }

    if (env === "prePrd") {
      if (prePrdValue === stgValue && prePrdValue === prdValue) return "bg-green-100 dark:bg-green-900/30"
      if (prePrdValue === stgValue) return "bg-blue-100 dark:bg-blue-900/30" // Matches stg only
      if (prePrdValue === prdValue) return "bg-indigo-100 dark:bg-indigo-900/30" // Matches prd only - CHANGED COLOR
      return "bg-red-100 dark:bg-red-900/30" // Matches nothing
    }

    if (env === "prd") {
      if (prdValue === stgValue && prdValue === prePrdValue) return "bg-green-100 dark:bg-green-900/30"
      if (prdValue === stgValue) return "bg-purple-100 dark:bg-purple-900/30" // Matches stg only
      if (prdValue === prePrdValue) return "bg-indigo-100 dark:bg-indigo-900/30" // Matches pre-prd only - CHANGED COLOR
      return "bg-red-100 dark:bg-red-900/30" // Matches nothing
    }

    return ""
  }

  // Function to get color for side by side comparison
  const getSideBySideColor = (index: number, env: EnvironmentType) => {
    if (env === env1 || env === env2) {
      const env1Data = getEnvData(env1)
      const env2Data = getEnvData(env2)

      const env1Value = index < env1Data.length ? env1Data[index].groupTag : undefined
      const env2Value = index < env2Data.length ? env2Data[index].groupTag : undefined

      if (env1Value === env2Value) {
        return "bg-green-100 dark:bg-green-900/30" // Both match
      } else {
        return "bg-red-100 dark:bg-red-900/30" // Different
      }
    }
    return ""
  }

  // Function to get tooltip text for side by side comparison
  const getSideBySideTooltip = (groupTag: string, currentEnv: EnvironmentType) => {
    const otherEnv = currentEnv === env1 ? env2 : env1
    const otherEnvData = getEnvData(otherEnv)
    const otherEnvIndex = otherEnvData.findIndex((item) => item.groupTag === groupTag)

    if (otherEnvIndex !== -1) {
      return `${getEnvDisplayName(otherEnv)}: ${otherEnvIndex}`
    }
    return "Only exists in this environment"
  }

  // Function to get border style for highlighted cells
  const getHighlightBorder = (index: number, env: EnvironmentType) => {
    return shouldHighlight(index, env) ? "border-2 border-blue-500" : ""
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>GroupTag Comparison</CardTitle>
        <div className="flex flex-wrap gap-2 text-sm">
          <div className="flex items-center">
            <div className="w-4 h-4 mr-1 bg-green-100 border"></div>
            <span>All match</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 mr-1 bg-blue-100 border"></div>
            <span>STG & PRE-PRD match</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 mr-1 bg-purple-100 border"></div>
            <span>STG & PRD match</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 mr-1 bg-indigo-100 border"></div>
            <span>PRE-PRD & PRD match</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 mr-1 bg-red-100 border"></div>
            <span>All different</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="mb-4">
            <TabsTrigger value="table">Table View</TabsTrigger>
            <TabsTrigger value="sideBySide">Side by Side</TabsTrigger>
          </TabsList>
          <TabsContent value="table">
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Index</TableHead>
                    <TableHead>STG</TableHead>
                    <TableHead>PRE-PRD</TableHead>
                    <TableHead>PRD</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {indices.map((index) => (
                    <TableRow key={index}>
                      <TableCell>{index}</TableCell>
                      <TableCell
                        className={`${getCellColor(index, "stg")} ${getHighlightBorder(index, "stg")}`}
                        onMouseEnter={() => index < stgData.length && setHoveredGroupTag(stgData[index].groupTag)}
                        onMouseLeave={() => setHoveredGroupTag(null)}
                      >
                        {index < stgData.length ? (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span className="cursor-help">{stgData[index].groupTag}</span>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>{getTooltipText(stgData[index].groupTag, "stg")}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        ) : (
                          "—"
                        )}
                      </TableCell>
                      <TableCell
                        className={`${getCellColor(index, "prePrd")} ${getHighlightBorder(index, "prePrd")}`}
                        onMouseEnter={() => index < prePrdData.length && setHoveredGroupTag(prePrdData[index].groupTag)}
                        onMouseLeave={() => setHoveredGroupTag(null)}
                      >
                        {index < prePrdData.length ? (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span className="cursor-help">{prePrdData[index].groupTag}</span>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>{getTooltipText(prePrdData[index].groupTag, "prePrd")}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        ) : (
                          "—"
                        )}
                      </TableCell>
                      <TableCell
                        className={`${getCellColor(index, "prd")} ${getHighlightBorder(index, "prd")}`}
                        onMouseEnter={() => index < prdData.length && setHoveredGroupTag(prdData[index].groupTag)}
                        onMouseLeave={() => setHoveredGroupTag(null)}
                      >
                        {index < prdData.length ? (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span className="cursor-help">{prdData[index].groupTag}</span>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>{getTooltipText(prdData[index].groupTag, "prd")}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        ) : (
                          "—"
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>
          <TabsContent value="sideBySide">
            <div className="flex flex-col md:flex-row gap-4 mb-4">
              <div className="flex-1 space-y-2">
                <Label htmlFor="env1">Environment 1</Label>
                <Select value={env1} onValueChange={(value) => setEnv1(value as EnvironmentType)}>
                  <SelectTrigger id="env1">
                    <SelectValue placeholder="Select environment" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="stg">STG</SelectItem>
                    <SelectItem value="prePrd">PRE-PRD</SelectItem>
                    <SelectItem value="prd">PRD</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex-1 space-y-2">
                <Label htmlFor="env2">Environment 2</Label>
                <Select value={env2} onValueChange={(value) => setEnv2(value as EnvironmentType)}>
                  <SelectTrigger id="env2">
                    <SelectValue placeholder="Select environment" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="stg">STG</SelectItem>
                    <SelectItem value="prePrd">PRE-PRD</SelectItem>
                    <SelectItem value="prd">PRD</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle>{getEnvDisplayName(env1)}</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Index</TableHead>
                        <TableHead>groupTag</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {getEnvData(env1).map((item, index) => (
                        <TableRow key={index}>
                          <TableCell>{index}</TableCell>
                          <TableCell
                            className={`${getSideBySideColor(index, env1)} ${getHighlightBorder(index, env1)}`}
                            onMouseEnter={() => setHoveredGroupTag(item.groupTag)}
                            onMouseLeave={() => setHoveredGroupTag(null)}
                          >
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <span className="cursor-help">{item.groupTag}</span>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>{getSideBySideTooltip(item.groupTag, env1)}</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>{getEnvDisplayName(env2)}</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Index</TableHead>
                        <TableHead>groupTag</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {getEnvData(env2).map((item, index) => (
                        <TableRow key={index}>
                          <TableCell>{index}</TableCell>
                          <TableCell
                            className={`${getSideBySideColor(index, env2)} ${getHighlightBorder(index, env2)}`}
                            onMouseEnter={() => setHoveredGroupTag(item.groupTag)}
                            onMouseLeave={() => setHoveredGroupTag(null)}
                          >
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <span className="cursor-help">{item.groupTag}</span>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>{getSideBySideTooltip(item.groupTag, env2)}</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        <div className="mt-6">
          <h3 className="text-lg font-medium mb-2">Summary of Differences</h3>
          <div className="space-y-2">
            {indices.map((index) => {
              const stgValue = index < stgData.length ? stgData[index].groupTag : "—"
              const prePrdValue = index < prePrdData.length ? prePrdData[index].groupTag : "—"
              const prdValue = index < prdData.length ? prdData[index].groupTag : "—"

              // Skip if all values are the same
              if (stgValue === prePrdValue && prePrdValue === prdValue) return null

              return (
                <div key={index} className="p-2 border rounded-md">
                  <p className="font-medium">Index {index}:</p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mt-1">
                    <div
                      className={`p-1 rounded ${getCellColor(index, "stg")} ${
                        stgValue === hoveredGroupTag ? "border-2 border-blue-500" : ""
                      }`}
                      onMouseEnter={() => stgValue !== "—" && setHoveredGroupTag(stgValue)}
                      onMouseLeave={() => setHoveredGroupTag(null)}
                    >
                      <span className="font-medium">STG:</span> {stgValue}
                    </div>
                    <div
                      className={`p-1 rounded ${getCellColor(index, "prePrd")} ${
                        prePrdValue === hoveredGroupTag ? "border-2 border-blue-500" : ""
                      }`}
                      onMouseEnter={() => prePrdValue !== "—" && setHoveredGroupTag(prePrdValue)}
                      onMouseLeave={() => setHoveredGroupTag(null)}
                    >
                      <span className="font-medium">PRE-PRD:</span> {prePrdValue}
                    </div>
                    <div
                      className={`p-1 rounded ${getCellColor(index, "prd")} ${
                        prdValue === hoveredGroupTag ? "border-2 border-blue-500" : ""
                      }`}
                      onMouseEnter={() => prdValue !== "—" && setHoveredGroupTag(prdValue)}
                      onMouseLeave={() => setHoveredGroupTag(null)}
                    >
                      <span className="font-medium">PRD:</span> {prdValue}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
